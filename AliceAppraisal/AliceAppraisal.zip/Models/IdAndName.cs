﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AliceAppraisal.Models {
	public class IdAndName {
		public int Id { get; set; }
		public string Name { get; set; }
	}
}
