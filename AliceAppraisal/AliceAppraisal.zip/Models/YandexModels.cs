﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AliceAppraisal.Models {
    public class YaDatetime {
        public int Year { get; set; }
        public bool YearIsRelative { get; set; }
    }
}
