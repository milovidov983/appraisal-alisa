﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AliceAppraisal.Static {
    public static class Slots {
        public const string Make = "make";
        public const string Model = "model";
        public const string ManufacureYear = "manufacure_year";
        public const string Raw = "raw";
        public const string Body = "body";
        public const string Gearbox = "gearbox";
        public const string Engine = "engine";
        public const string Drive = "drive";
        public const string Number = "number";
        public const string Equipment = "equipment";
        public const string City = "city";
        public const string Run = "run";
        public const string Generation = "generation";

    }
}
