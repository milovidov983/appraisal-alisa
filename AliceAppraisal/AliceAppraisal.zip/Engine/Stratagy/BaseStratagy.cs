﻿using AliceAppraisal.Engine.Services;
using AliceAppraisal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AliceAppraisal.Engine.Stratagy {
	public abstract class BaseStratagy {
        protected ITextGeneratorService textGeneratorService;

        protected BaseStratagy(IServiceFactory serviceFactory) {
            textGeneratorService = serviceFactory.GetTextGeneratorService();
        }

        public bool IsSuitableStrategy(AliceRequest request, State state) {
            return Check(request, state ?? new State());
        }

        public async Task<AliceResponse> Run(AliceRequest request, State state) {
            return await CreateResponse(request, state);
        }

        protected virtual async Task<AliceResponse> CreateResponse(AliceRequest request, State state) {
            var response = new AliceResponse(request);
            var simple = await Respond(request, state);

            response.State = state;
            response.Response.Text = simple.Text;
            response.Response.Tts = string.IsNullOrEmpty(simple.Tts) ? simple.Text : simple.Tts;
            if (simple.Buttons != null) {
                response.Response.Buttons = simple.Buttons.Select(t => new Button { Title = t }).ToList();
            }

            return response;
        }


        protected abstract bool Check(AliceRequest request, State state);
        protected abstract Task<SimpleResponse> Respond(AliceRequest request, State state);

    }
}
